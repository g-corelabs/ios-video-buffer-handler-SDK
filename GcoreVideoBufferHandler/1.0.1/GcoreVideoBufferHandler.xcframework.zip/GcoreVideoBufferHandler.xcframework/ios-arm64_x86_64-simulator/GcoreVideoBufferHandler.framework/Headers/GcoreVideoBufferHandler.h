#import <Foundation/Foundation.h>

//! Project version number for GcoreVideoBufferHandler.
FOUNDATION_EXPORT double GcoreVideoBufferHandlerVersionNumber;

//! Project version string for GcoreVideoBufferHandler.
FOUNDATION_EXPORT const unsigned char GcoreVideoBufferHandlerVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <GcoreVideoBufferHandler/PublicHeader.h>


